/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Teori_5;

/**
 *
 * @author MSii
 */
public class Main {
    public static void main(String[] args){
        Pekerja pekerja = new Pekerja("Thomas", 22, "Programmer", 7000000);
        System.out.println("Informasi Pekerjaan");
        System.out.println(pekerja.toString());
        
        pekerja.setNama("Dafa Rozan");
        System.out.println("\nSetelah Perubahan");
        System.out.println(pekerja.toString());
    }
}